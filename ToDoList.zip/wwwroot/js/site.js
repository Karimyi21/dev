﻿function addNewSkilInput() {
    const input = document.createElement("input");
    input.setAttribute('type', 'text');
    input.className = 'cv-input__skil';

    const parent = document.querySelector(".cv-form__skils");
    parent.appendChild(input);
}

function delSkilInput() {
    const inputs = document.querySelectorAll(".cv-input__skil");
    inputs[inputs.length - 1].remove();
}

function confirmSkils() {
    const skils = document.querySelectorAll(".cv-input__skil");
    let skilsString = '';
    for (var skil of skils) {
        skilsString += skil.value + "[;]";
    }

    const hiddenInputSkils = document.querySelector(".cv-input__skils"); /*все в скрытый которй потом получает модель с листом */
    hiddenInputSkils.value = skilsString;
}
