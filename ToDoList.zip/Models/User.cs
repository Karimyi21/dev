﻿using Microsoft.AspNetCore.Identity;

namespace ToDoList.Models
{
    public class User : IdentityUser
    {
        public List<WorkTask> WorkTasks { get; set; }
    }
}
