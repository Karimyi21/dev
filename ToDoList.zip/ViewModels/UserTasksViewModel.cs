﻿namespace ToDoList.ViewModels
{
    public class UserTasksViewModel
    {
        public IEnumerable<AddTaskViewModel> WorkTasks { get; set; }
    }
}
