﻿using ToDoList.Enums;

namespace ToDoList.ViewModels
{
    public class AddTaskViewModel
    {

        public string? Description { get; set; }

        public string? Name { get; set; }
        public string? UserId { get; set; }

        public DateTime CreationTime { get; set; }

        public int Id { get; set; }

        public Status Type { get; set; }

    }
}
