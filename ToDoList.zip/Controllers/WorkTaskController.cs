﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToDoList.Contexts;
using ToDoList.Models;
using ToDoList.ViewModels;
using ToDoList.Enums;

namespace ToDoList.Controllers
{
    [Authorize]
    public class WorkTaskController : Controller
    {
        private readonly ApplicationContext _applicationContext;
        private readonly UserManager<User> _userManager;

        public WorkTaskController(
            ApplicationContext applicationContext,
            UserManager<User> userManager)
        {
            _applicationContext = applicationContext;
            _userManager = userManager;
        }


        [HttpGet]
        public async Task<IActionResult> UserWorkTask()
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);
            var Ads = await _applicationContext.WorkTasks
                .Where(ad => ad.UserId == user.Id)
                .ToListAsync();
            var userAds = Ads
                .OrderByDescending(ad => ad.CreationTime)
                .ToList();

            var list = new List<AddTaskViewModel>();
            foreach (var userAd in userAds)
            {
                var AddViewModel = new AddTaskViewModel
                {
                    CreationTime = userAd.CreationTime,
                    Name = userAd.Name,
                    Description = userAd.Description,
                    Type = userAd.Type,
                    Id = userAd.Id,
                };
                list.Add(AddViewModel);
            }

            var viewModel = new UserTasksViewModel
            {
                WorkTasks = list
            };

            return View(viewModel);
        }


        [HttpGet]
        public IActionResult AddTask()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddTask(AddTaskViewModel model)
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);

            var log = new WorkTask
            {
                UserId = user.Id,
                Name = model.Name,
                Description = model.Description,
                CreationTime = DateTime.Now,
                Type = Status.Todo
            };

            await _applicationContext.WorkTasks.AddAsync(log);
            await _applicationContext.SaveChangesAsync();

            return Redirect("UserWorkTask");
        }


        public async Task<IActionResult> Delete(int id)
        {
            var Ads = await _applicationContext.WorkTasks.FirstOrDefaultAsync(ad => ad.Id == id);
            var user = await _userManager.GetUserAsync(HttpContext.User);

            if (Ads.UserId == user.Id)
            {
                if (Ads != null)
                {
                    _applicationContext.WorkTasks.Remove(Ads);
                    await _applicationContext.SaveChangesAsync();
                }
            }
            return RedirectToAction("UserWorkTask");
        }


        [HttpGet]
        public async Task<IActionResult> EditAd(int? id)
        {
            WorkTask ads = await _applicationContext.WorkTasks.FirstOrDefaultAsync(ad => ad.Id == id);
            var user = await _userManager.GetUserAsync(HttpContext.User);

            if (ads.UserId == user.Id)
            {
                if (ads != null)
                {
                    return View(ads);
                }
            }
            return RedirectToAction("UserWorkTask");
        }

        [HttpPost]
        public async Task<IActionResult> EditAd(WorkTask ads)
        {

            _applicationContext.Entry(ads).State = EntityState.Modified;
            await _applicationContext.SaveChangesAsync();
            return RedirectToAction("UserWorkTask");
        }
    }
}
