﻿namespace ToDoList.Enums
{
    public enum Status
    {
        Unknown = 0,
        Todo = 1,
        Completed = 2,
        Close = 3
    }
}
